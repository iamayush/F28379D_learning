/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z63
 */

#ifndef xconfig_blink_cpu01__
#define xconfig_blink_cpu01__



#endif /* xconfig_blink_cpu01__ */ 
