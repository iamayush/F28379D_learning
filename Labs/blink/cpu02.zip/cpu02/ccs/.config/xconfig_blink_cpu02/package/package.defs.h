/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z63
 */

#ifndef xconfig_blink_cpu02__
#define xconfig_blink_cpu02__



#endif /* xconfig_blink_cpu02__ */ 
